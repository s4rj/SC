<?php 

$dev1 = 'ilwankhomang';
$dev2 = 'diikuti.oleh';
$dev3 = '100005557368840';
$dev4 = 'wahyuga.ziip';
$dev5 = 'radenymous';



echo' <div id="login" class="jumbotron" style="padding:20px;color: white;background: rgb(106, 90, 205);text-align:center;max-width:1024px;margin: 1% auto;">
 <div align="center">
  <h1>Follow Developer</h1>


<!-- Developers Coday Likers -->







<table width="100%">







<tr>















<td align="left">







<a href="http://m.facebook.com/boy.anarcy">







<img style="border: 2px solid #000; padding: 2px; margin: 2px; width: 50px; height: 50px;" src="https://graph.facebook.com/boy.anarcy/picture?type=normal" width="45" height="55"/></a><br/>







<iframe align="center" src="//www.facebook.com/plugins/subscribe.php?href=https%3A%2F%2Fwww.facebook.com%2Fboy.anarcy&layout=box_count& show_faces=false&colorscheme=dark&font&width=75&appId=231341246993923" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:52px; height:60px;" allowTransparency="true"></iframe></td>















<td align="center">







<a href="http://m.facebook.com/'.$dev1.'">







<img style="border: 2px solid #000; padding: 2px; margin: 2px; width: 50px; height: 50px;" src="https://graph.facebook.com/'.$dev1.'/picture?type=normal" width="45" height="55"/> </a><br/>







<iframe align="center" src="//www.facebook.com/plugins/subscribe.php?href=https%3A%2F%2Fwww.facebook.com%2F'.$dev1.'&layout=box_count& show_faces=false&colorscheme=light&font&width=75&appId=231341246993923" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:52px; height:60px;" allowTransparency="true"></iframe></td>















<td align="right">







<a href="http://m.facebook.com/'.$dev2.'">







<img style="border: 2px solid #000; padding: 2px; margin: 2px; width: 50px; height: 50px;" src="https://graph.facebook.com/'.$dev2.'/picture?type=normal" width="45" height="55"/> </a><br/>







<iframe align="center" src="//www.facebook.com/plugins/subscribe.php?href=https%3A%2F%2Fwww.facebook.com%2F'.$dev2.'&layout=box_count& show_faces=false&colorscheme=light&font&width=75&appId=231341246993923" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:52px; height:60px;" allowTransparency="true"></iframe></td>















</tr>







<tr>















<td align="left">







<a href="http://m.facebook.com/'.$dev3.'">







<img style="border: 2px solid #000; padding: 2px; margin: 2px; width: 50px; height: 50px;" src="https://graph.facebook.com/'.$dev3.'/picture?type=normal" width="45" height="55"/></a><br/>







<iframe align="center" src="//www.facebook.com/plugins/subscribe.php?href=https%3A%2F%2Fwww.facebook.com%2F'.$dev3.'&layout=box_count& show_faces=false&colorscheme=dark&font&width=75&appId=231341246993923" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:52px; height:60px;" allowTransparency="true"></iframe></td>















<td align="center">







<a href="http://m.facebook.com/'.$dev4.'">







<img style="border: 2px solid #000; padding: 2px; margin: 2px; width: 50px; height: 50px;" src="https://graph.facebook.com/'.$dev4.'/picture?type=normal" width="45" height="55"/> </a><br/>







<iframe align="center" src="//www.facebook.com/plugins/subscribe.php?href=https%3A%2F%2Fwww.facebook.com%2F'.$dev4.'&layout=box_count& show_faces=false&colorscheme=light&font&width=75&appId=231341246993923" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:52px; height:60px;" allowTransparency="true"></iframe></td>















<td align="right">







<a href="http://m.facebook.com/'.$dev5.'">







<img style="border: 2px solid #000; padding: 2px; margin: 2px; width: 50px; height: 50px;" src="https://graph.facebook.com/'.$dev5.'/picture?type=normal" width="45" height="55"/> </a><br/>







<iframe align="center" src="//www.facebook.com/plugins/subscribe.php?href=https%3A%2F%2Fwww.facebook.com%2F'.$dev5.'&layout=box_count& show_faces=false&colorscheme=light&font&width=75&appId=231341246993923" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:52px; height:60px;" allowTransparency="true"></iframe></td>







</tr>







</table>


</div>
</div>

'; ?>

