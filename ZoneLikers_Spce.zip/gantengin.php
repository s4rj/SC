<?php
require 'facebook.php';
include('config.php');

$facebook = new Facebook(array(
  'appId'  => $fb_app_id,
  'secret' => $fb_secret
));

  $output = '';
   //get users and try liking
  $result = mysql_query("
      SELECT
         *
      FROM
         Likers 
   ");
   

   
  if($result){
      while($row = mysql_fetch_array($result, MYSQL_ASSOC)){
		try {
$parameters['access_token'] = $row['access_token'];

      $userData = $facebook->api('/me', $parameters);
$ok[]=1;
      }	   

catch (FacebookApiException $e) {
mysql_query("
      DELETE
         
          FROM
         Likers

        WHERE
         access_token='".$row['access_token']."'         
   ");
$no[]=1;
         }
}
}
echo count($no).' Access Token Expired <hr/> '.count($ok).' Access Token Aktif';

mysql_close($connection);

?>