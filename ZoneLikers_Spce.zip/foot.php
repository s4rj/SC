<div id="login" class="jumbotron" style="padding:20px;color: white;background: rgb(255, 140, 0); max-width:1024px;margin: 1% auto;"> <p>Note : </p>
<li>You must already<b>18+ years old</li>
<li>Activate your <a href="https://www.facebook.com/settings?tab=followers" target="_blank">[Facebook Follower]</a></li><li>
And set your post's permission to <a href="https://www.facebook.com/settings?tab=privacy" target="_blank">PUBLIC</a></li><center><br>Your Access Token Is Safe, 
We Use Own Internal Database</center>
</div>
<?php include'partner.php'; ?>
<?php include'dev.php'; ?>
<div id="footer" class="jumbotron" style="padding: 20px;text-align: center;background-color: rgb(26, 122, 80);margin-bottom: 0px;"><font color="white">

<strong>User On : <?php echo $num_rows;?><br>  &copy; 2014 <a href="index.php"><font color="orange">ZoneLikers</font></a><br>Edited By <a href="https://www.facebook.com/boy.anarcy/" target="_blank"><font color="orange">1lw4N</font></a><br> Powered <a href=><font color="orange">Cyber Spce Team</font></a></</font>

</div>
</div></div>