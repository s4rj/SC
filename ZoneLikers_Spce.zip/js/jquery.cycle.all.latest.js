    $(document).ready(function() {
		$('#show-right').click(function (){
			$('.nav').toggle('fast');
		});
	});      
    $(document).ready(function() {
	$('.charms').hide();
		$('#switch').click(function (){
			$('.charms').fadeIn('normal');
		});
		$('#seemore').click(function (){
			$('.charms').fadeIn('normal');
		});
	$('#close').click(function (){
			$('.charms').fadeOut('normal');
		});
	});