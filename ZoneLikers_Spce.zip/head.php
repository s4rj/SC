
<?php

include'config.php';

$count = mysql_query("SELECT * FROM Likers");

$num_rows = mysql_num_rows($count);

?>
<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTDa/xhtml-mobile10.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head> 
<title>ZoneLikers Spce | Increase Likes Facebook</title>
<meta name="google-site-verification" content="N1H8zeuEH5YPJsKBZY99_8bzBePeJGpTTTj-700RZPY" /> <meta name="alexaVerifyID" content="pzbxeujvSvFchnQ48uKscsbKeRA"> <meta name="wot-verification" content="a93490b8b496266a655b"> <meta name="description" content="Autolike Facebook I Get Free Like For Status And Photo Instant"> <meta name="keywords" content="Autolike Facebok,Autolike Photo,Autolike Status,Autolike Fans Page,Bot komen,Bot Like,Bom Like,Bomer Like,Big Like,Facebook,Google,Yahoo,Mywapblog,Bot koplak,Alexa,Ping,Twitter,pzbxeujvSvFchnQ48uKscsbKeRA,a93490b8b496266a655b">
<meta name="description" content="Free likes and comments for your faceboook's status, photos and videos. Use it many time as you like to get unlimited likes. Share with your friends now !! ">

<meta name="keywords" content="free like facebook, free comment facebook,  free follower facebook, autolike, autocomment, autofollower, www.hublaa.me, facebook trick, 100+ likes">

<meta name="author" content="ilwan">

<meta property="og:image" content="../img/icon.png"/>  

<script src="../js/jquery-1.8.1.js"></script>

<script src="../js/jquery.cycle.all.latest.js"></script>

<link rel="stylesheet" href="../css/style.css" type="text/css">

<link rel="stylesheet" href="../css/style.default.css" type="text/css">

<link rel="stylesheet" href="../css/block.css" type="text/css">

<link rel="shortcut icon" href="http://stevendie.xtgem.com/icon/menu/1stv_Facebook.png">

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>

<!-- Include all compiled plugins (below), or include individual files as needed -->

<script src="../js/bootstrap.min.js"></script>

<meta name="google-translate-customization" content="b7c4e06ff4fcb951-33850dbb22ebdcc0-g8fbf4b9958e0f9f9-10"></meta>
<script src="http://stevendie.xtgem.com/js/widget/made_in_indonesia.js"></script><script language="javascript">cot("http://stevendie.xtgem.com/js/widget/made_in_indonesia.png")</script>
<script type="text/javascript">
  var _pop = _pop || [];
  _pop.push(['siteId', 342471]);
  _pop.push(['minBid', 0.005]);
  _pop.push(['popundersPerIP', 1]);
  _pop.push(['delayBetween', 100]);
  _pop.push(['default', false]);
  _pop.push(['defaultPerDay', 3]);
  _pop.push(['topmostLayer', true]);
  (function() {
    var pa = document.createElement('script'); pa.type = 'text/javascript'; pa.async = true;
    var s = document.getElementsByTagName('script')[0]; 
    pa.src = '//c1.popads.net/pop.js';
    pa.onerror = function() {
      var sa = document.createElement('script'); sa.type = 'text/javascript'; sa.async = true;
      sa.src = '//c2.popads.net/pop.js';
      s.parentNode.insertBefore(sa, s);
    };
    s.parentNode.insertBefore(pa, s);
  })();
</script>
</head>

<body>


<div class="jumbotron" style="margin: 1% auto;margin-top:-20px; background:url(http://i.imgur.com/zHNCk2e.gif)">
<div id="login" class="jumbotron" style="padding:20px;color: white;background: Chocolate;text-align:center;max-width:1024px;margin: 1% auto;">
<h1 style="text-align: center;"><text style="font: italic small-caps bold 25px/20px Helvetica, sans-serif;">Increase Likes On Your Facebook Status</font></div>