A Pen created at CodePen.io. You can find this one at https://codepen.io/LukyVj/pen/KIoCs.

 Designed by <a href="http://dribbble.com/Cdnc">@KevinCdnc</a> - Not yet on dribbble :D 

Note that the content is created via the SCSS stylesheet. So you can change any values you want, as well as the colors. 