<!-- FAQIH MUCHAMAD -->
<?php
$emailku = 'sarjoz99@gmail.com';
?>